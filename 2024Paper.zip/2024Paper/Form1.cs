﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _2024Paper
{
    public partial class btnLogin : Form
    {

        string correctUsername = "admin";
        string correctPassword = "admin123";
        public btnLogin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string enteredUsername = txtUsername.Text;
            string enteredPassword = txtPassword.Text;

          

            if(enteredUsername == correctUsername && enteredPassword == correctPassword){
                MessageBox.Show("Login Succfull");
                Dashboard dashboard = new Dashboard();
                this.Hide();
                dashboard.Show();
            }
            else
            {
                MessageBox.Show("UNsuccess");

            }

        }
    }
}
